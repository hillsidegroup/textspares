<?php
if(!defined('IN_TEXTSPARES')) exit;

error_reporting(E_ALL);
date_default_timezone_set('UTC');

define('BASE','http://'.$_SERVER['HTTP_HOST'].'/');

define('EZSQL_DB_USER', 'dbo414074512');				// <-- mysql db user
define('EZSQL_DB_PASSWORD', 'sN4d7s510x0c');				// <-- mysql db password
define('EZSQL_DB_NAME', 'db414074512');					// <-- mysql db pname
define('EZSQL_DB_HOST', 'localhost:/tmp/mysql5.sock');	// <-- mysql server host

?>